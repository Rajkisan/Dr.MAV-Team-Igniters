import sqlite3

def delete_all_patient_entries():
    try:
        conn = sqlite3.connect('site.db')
        cursor = conn.cursor()

        # Delete all records from the patient_entries table
        cursor.execute('DELETE FROM patient_entries')
        
        conn.commit()
        print("All records from patient_entries table deleted successfully.")

    except sqlite3.Error as e:
        print(f"Error deleting records: {e}")

    finally:
        if conn:
            conn.close()

# Call the function to delete all records
delete_all_patient_entries()
